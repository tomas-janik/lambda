# production-ready-serverless-workshop-devternity-demo

Demo project for the Production-Ready Serverless workshop at DevTernity